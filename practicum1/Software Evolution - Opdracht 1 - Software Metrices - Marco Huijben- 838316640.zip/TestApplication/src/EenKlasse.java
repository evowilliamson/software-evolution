import java.io.File;
import java.io.IOException;

public class EenKlasse {

	
	public void Method1(int x){
		int j = 0;
		
		if (x >6)
		{
			System.out.println("d");
		}
		
		for(int i = 0; i < x; i++) {
			if (i == 2) {
				System.out.println("x");
			}
			else
			{
				System.out.println("c");
			}
			
			j++;
		}
		
		System.out.println(j);
		
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
		System.out.println(j);
	}

}
