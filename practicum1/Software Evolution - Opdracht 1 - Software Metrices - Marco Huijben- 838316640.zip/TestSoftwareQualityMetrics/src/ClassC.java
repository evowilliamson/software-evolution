import java.util.ArrayList;
import java.util.HashSet;

public class ClassC {

	int a = 0;
	
	public int contentsOfMethodIsDuplicatedInThisClass1() {
		// line comment 1
		int temp = 100;
		int jjj = 100;
		int c = 0;
		// line comment 2
		int d = 0;
		int e = 0;
		return temp;
	}
	
	public int contentsOfMethodIsDuplicatedInThisClass2() {
		// line comment 1
		int temp = 100;
		int jjj = 100;
		int c = 0;
		// line comment 2
		int d = 0;
		int e = 0;
		return temp;
	}
	
}
