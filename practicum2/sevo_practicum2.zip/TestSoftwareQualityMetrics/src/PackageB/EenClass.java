package PackageB;

public class EenClass {
	public void MethodQwerty(String a, int r) {
		for(int i=0; i<r;i++) {
			System.out.println("");
		}
	}
}
