package PackageB;

public class TweedeClass {
	public void MethodA()
	{
		int j = 5*6;
		if (j == 45) {
			System.out.println(j);
		}
	}
}
