package PackageA;

public class EenClass {
	public void AMethod(){
		for(int i=0; i< 10;i++) {
			System.out.println("regel: " + i );
		}
	}
}
