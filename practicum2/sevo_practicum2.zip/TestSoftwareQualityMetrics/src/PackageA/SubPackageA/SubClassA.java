package PackageA.SubPackageA;

public class SubClassA {
	private int _waarde;
	
	public SubClassA(int waarde) {
		_waarde = waarde;
	}
	
	public void Method1() {
		System.out.println(_waarde);
	}
}
